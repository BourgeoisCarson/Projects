﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TexanTurnkey.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace TexanTurnkey.Controllers
{
    public class CustomersController : Controller
    {
        private readonly TexanTurnkeyDB _context;
        private readonly IWebHostEnvironment webHostEnvironment;

        public CustomersController(TexanTurnkeyDB context, IWebHostEnvironment webHostEnvironment )
        {
            _context = context;
            this.webHostEnvironment = webHostEnvironment;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Customers.ToListAsync());
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(short? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.custID == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("custID,custFirstName,custLastName,custCompany,custPhoneNum,custEmailAddress,custRoutingNum,custAddress")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(short? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(short id, [Bind("custID,custFirstName,custLastName,custCompany,custPhoneNum,custEmailAddress,custRoutingNum,custAddress")] Customer customer)
        {
            if (id != customer.custID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.custID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(short? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.custID == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(short id)
        {
            var customer = await _context.Customers.FindAsync(id);
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



       
        public IActionResult CreateFile(PdfModel model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFileName = null;
                if(model.FileContent != null)
                {
                   string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "PdfFiles");
                   uniqueFileName = Guid.NewGuid().ToString() + "_" + model.FileContent.FileName;
                   string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    model.FileContent.CopyTo(new FileStream(filePath, FileMode.Create));
                }

                PdfModel PdfModels = new PdfModel
                {
                    FileName = model.FileName,
                    custID = model.custID,
                    PhotoPath = model.PhotoPath
                };
                _context.Add(PdfModels);             
                return RedirectToAction("CreateFile");
            }
            ViewData["custID"] = new SelectList(_context.Customers, "custID", "custCompany", model.custID);
            return View();
        }

        private bool CustomerExists(short id)
        {
            return _context.Customers.Any(e => e.custID == id);
        }
    }
}
