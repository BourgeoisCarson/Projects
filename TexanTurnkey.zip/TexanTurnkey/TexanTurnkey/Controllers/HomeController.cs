﻿using Geocoding;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TexanTurnkey.Models;
using Geocoding.Microsoft;

namespace TexanTurnkey.Controllers
{
    public class HomeController : Controller
    {
        private readonly TexanTurnkeyDB _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, TexanTurnkeyDB context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            Job locaitonJob = new Job();

            IGeocoder geocoder = new BingMapsGeocoder("Ah74SQ_KBeRLM33pHoaHP9Nk8VoiMpxvCCqcolhaUKdInPZT8N1MG6Qg1iWObSEf");
            IEnumerable<Address> addresses = await geocoder.GeocodeAsync(locaitonJob.addressAddress);

            

            var texanTurnkeyDB = _context.Jobs.Include(j => j.cust);
            return View(await texanTurnkeyDB.ToListAsync());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        
    }
}
