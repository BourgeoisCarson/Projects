﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class SupplierJob
    {
        [Key]
        public short JobID { get; set; }
        [Key]
        public short supplierID { get; set; }

        [ForeignKey(nameof(JobID))]
        [InverseProperty("SupplierJobs")]
        public virtual Job Job { get; set; }
        [ForeignKey(nameof(supplierID))]
        [InverseProperty(nameof(Supplier.SupplierJobs))]
        public virtual Supplier supplier { get; set; }
    }
}
