﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using System.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

#nullable disable

namespace TexanTurnkey.Models
{
    [Table("PdfModel")]
    public partial class PdfModel
    {
       

        [Key]
        public short FileID { get; set; }
        [StringLength(50)]
        public string FileName { get; set; }
        
        [NotMapped]
        [Required]
        [DataType(DataType.Upload)]
        [Display(Name = "Select File")]
        public IFormFile FileContent { get; set; }
        public short? custID { get; set; }
        public short? jobID { get; set; }

        public string PhotoPath { get; set; }

        [ForeignKey(nameof(custID))]
        [InverseProperty(nameof(Customer.pdfModel))]
        public virtual Customer cust { get; set; }
    }

   
}
