﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Jobs = new HashSet<Job>();
            Plans = new HashSet<Plan>();
            custPayments = new HashSet<custPayment>();
        }

        [Key]
        public short custID { get; set; }
        [Required]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$")]
        [StringLength(50, ErrorMessage = "First name cannot be longer than 50")]
        [Display(Name = "First Name")]
        public string custFirstName { get; set; }
        [Required]
        [StringLength(50)]
        [Display(Name = "LastName")]
        public string custLastName { get; set; }
        [StringLength(50)]
        [Display(Name = "Company Name")]
        public string custCompany { get; set; }
        [StringLength(50)]
        [Display(Name = "Phone Number")]
        public string custPhoneNum { get; set; }
        [StringLength(50)]
        [Display(Name = "Email Address")]
        public string custEmailAddress { get; set; }
        [StringLength(50)]
        [Display(Name = "Routing Number")]
        public string custRoutingNum { get; set; }
        [StringLength(50)]
        [Display(Name = "Company Address")]
        public string custAddress { get; set; }

        [InverseProperty(nameof(PdfModel.cust))]
        public virtual PdfModel pdfModel { get; set; }

        [InverseProperty(nameof(Job.cust))]
        public virtual ICollection<Job> Jobs { get; set; }
        [InverseProperty(nameof(Plan.cust))]
        public virtual ICollection<Plan> Plans { get; set; }
        [InverseProperty(nameof(custPayment.cust))]
        public virtual ICollection<custPayment> custPayments { get; set; }
    }
}
