﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class contractorPayment
    {
        [Key]
        public short paymentID { get; set; }
        public short? contractorID { get; set; }
        [StringLength(50)]
        public string jobID { get; set; }
        [Column(TypeName = "date")]
        public DateTime? paymentDate { get; set; }
        [Column(TypeName = "money")]
        public decimal? paymentAmount { get; set; }

        [ForeignKey(nameof(contractorID))]
        [InverseProperty(nameof(Contractor.contractorPayments))]
        public virtual Contractor contractor { get; set; }
    }
}
