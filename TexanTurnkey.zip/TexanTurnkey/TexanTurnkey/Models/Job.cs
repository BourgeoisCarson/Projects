﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class Job
    {
        public Job()
        {
            ContractorJobs = new HashSet<ContractorJob>();
            SupplierJobs = new HashSet<SupplierJob>();
        }


        [Key]
        public short JobID { get; set; }
        [Required]
        [StringLength(50)]
        [Display(Name = "Address")]
        public string addressAddress { get; set; }
        [Column(TypeName = "datetime")]
        [Display(Name = "Date")]
        public DateTime pourDate { get; set; }

        [Display(Name = "Customer")]
        public short? custID { get; set; }
        [StringLength(50)]
        [Display(Name = "Pour Size(sqft)")]
        public string pourSize { get; set; }
        [Column(TypeName = "money")]
        [Display(Name = "Amount Paid To You")]
        //[DisplayFormat(DataFormatString = "{$:}", ApplyFormatInEditMode = true)]
        public decimal? amountRecieved { get; set; }
        [Column(TypeName = "money")]
        [Display(Name = "Total Material Cost")]
        public decimal? materialCost { get; set; }
        [Column(TypeName = "money")]
        [Display(Name = "Total paid to contractors")]
        public decimal? payedToContractor { get; set; }

        [ForeignKey(nameof(custID))]
        [InverseProperty(nameof(Customer.Jobs))]
        public virtual Customer cust { get; set; }
        [InverseProperty(nameof(ContractorJob.Job))]
        public virtual ICollection<ContractorJob> ContractorJobs { get; set; }
        [InverseProperty(nameof(SupplierJob.Job))]
        public virtual ICollection<SupplierJob> SupplierJobs { get; set; }

       
    }

    public partial class Locations
    {
        public int LocationId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }

        public Locations(int locid, string title, string desc, double latitude, double longitude)
        {
            this.LocationId = locid;
            this.Title = title;
            this.Description = desc;
            this.Latitude = latitude;
            this.Longitude = longitude;
        }
    }

    public partial class LocationLists
    {
        public IEnumerable<Locations> LocationList { get; set; }
    }
}
