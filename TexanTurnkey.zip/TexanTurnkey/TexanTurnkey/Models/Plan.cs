﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class Plan
    {
        [Key]
        public short planID { get; set; }
        public short? custID { get; set; }

        [ForeignKey(nameof(custID))]
        [InverseProperty(nameof(Customer.Plans))]
        public virtual Customer cust { get; set; }
    }
}
