﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using TexanTurnkey;
using TexanTurnkey.Models;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class TexanTurnkeyDB : DbContext
    {
      
        public TexanTurnkeyDB(DbContextOptions<TexanTurnkeyDB> options)
            : base(options)
        {
        }

        public virtual DbSet<Contractor> Contractors { get; set; }
        public virtual DbSet<ContractorJob> ContractorJobs { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<Login> Logins { get; set; }
        public virtual DbSet<PdfModel> PdfModels { get; set; }
        public virtual DbSet<Plan> Plans { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<SupplierJob> SupplierJobs { get; set; }
        public virtual DbSet<contractorPayment> contractorPayments { get; set; }
        public virtual DbSet<custPayment> custPayments { get; set; }
        public virtual DbSet<supplierPayment> supplierPayments { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Contractor>(entity =>
            {
                entity.Property(e => e.contractorAddress).IsFixedLength(true);

                entity.Property(e => e.contractorEmail).IsFixedLength(true);

                entity.Property(e => e.contractorPhone).IsFixedLength(true);
            });

            modelBuilder.Entity<ContractorJob>(entity =>
            {
                entity.HasKey(e => new { e.JobID, e.contractorID });

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.ContractorJobs)
                    .HasForeignKey(d => d.JobID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ContractorJobs_Jobs");

                entity.HasOne(d => d.contractor)
                    .WithMany(p => p.ContractorJobs)
                    .HasForeignKey(d => d.contractorID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ContractorJobs_Contractor");
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.custID)
                    .HasName("PK_Customers_1");
            });

            modelBuilder.Entity<Job>(entity =>
            {
                entity.HasOne(d => d.cust)
                    .WithMany(p => p.Jobs)
                    .HasForeignKey(d => d.custID)
                    .HasConstraintName("FK_Jobs_custID");
            });

            modelBuilder.Entity<Login>(entity =>
            {
                entity.HasKey(e => e.userName)
                    .HasName("PK_Table_1");
                
            });

            modelBuilder.Entity<PdfModel>(entity =>
            {
                entity.HasKey(e => e.FileID).
                HasName("PK_FileID");

                
            });

            modelBuilder.Entity<Plan>(entity =>
            {
                entity.Property(e => e.planID).ValueGeneratedNever();

                entity.HasOne(d => d.cust)
                    .WithMany(p => p.Plans)
                    .HasForeignKey(d => d.custID)
                    .HasConstraintName("FK_Plans_Customers");
            });

            modelBuilder.Entity<SupplierJob>(entity =>
            {
                entity.HasKey(e => new { e.JobID, e.supplierID });

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.SupplierJobs)
                    .HasForeignKey(d => d.JobID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SupplierJobs_Jobs");

                entity.HasOne(d => d.supplier)
                    .WithMany(p => p.SupplierJobs)
                    .HasForeignKey(d => d.supplierID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SupplierJobs_Suppliers");
            });

            modelBuilder.Entity<contractorPayment>(entity =>
            {
                entity.HasOne(d => d.contractor)
                    .WithMany(p => p.contractorPayments)
                    .HasForeignKey(d => d.contractorID)
                    .HasConstraintName("FK_contractorPayments_Contractor");
            });

            modelBuilder.Entity<custPayment>(entity =>
            {
                entity.HasOne(d => d.cust)
                    .WithMany(p => p.custPayments)
                    .HasForeignKey(d => d.custID)
                    .HasConstraintName("FK_custPayments_Customers");
            });

            modelBuilder.Entity<supplierPayment>(entity =>
            {
                entity.HasOne(d => d.supplier)
                    .WithMany(p => p.supplierPayments)
                    .HasForeignKey(d => d.supplierID)
                    .HasConstraintName("FK_supplierPayments_Suppliers");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
