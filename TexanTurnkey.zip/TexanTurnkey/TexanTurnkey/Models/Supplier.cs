﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class Supplier
    {
        public Supplier()
        {
            SupplierJobs = new HashSet<SupplierJob>();
            supplierPayments = new HashSet<supplierPayment>();
        }

        [Key]
        public short supplierID { get; set; }
        [Required]
        [StringLength(50)]
        [Display(Name = "Company Name")]
        public string companyName { get; set; }
        [StringLength(50)]
        [Display(Name = "Routing Number")]
        public string supplierRoutingNum { get; set; }
        [StringLength(50)]
        [Display(Name = "Email")]
        public string supplierEmail { get; set; }
        [StringLength(50)]
        [Display(Name = "Phone number")]
        public string supplierPhoneNum { get; set; }

        [InverseProperty(nameof(SupplierJob.supplier))]
        public virtual ICollection<SupplierJob> SupplierJobs { get; set; }
        [InverseProperty(nameof(supplierPayment.supplier))]
        public virtual ICollection<supplierPayment> supplierPayments { get; set; }
    }
}
