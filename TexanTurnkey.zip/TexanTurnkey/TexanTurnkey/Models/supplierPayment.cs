﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class supplierPayment
    {
        [Key]
        public short paymentID { get; set; }
        public short? productID { get; set; }
        [StringLength(50)]
        public string jobAddress { get; set; }
        public short? supplierID { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? paymentDate { get; set; }
        [Column(TypeName = "money")]
        public decimal amountPaid { get; set; }

        [ForeignKey(nameof(supplierID))]
        [InverseProperty(nameof(Supplier.supplierPayments))]
        public virtual Supplier supplier { get; set; }
    }
}
