﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    [Table("Contractor")]
    [Index(nameof(contractorID), Name = "IX_Contractor")]
    public partial class Contractor
    {
        public Contractor()
        {
            ContractorJobs = new HashSet<ContractorJob>();
            contractorPayments = new HashSet<contractorPayment>();
        }

        [Key]
        public short contractorID { get; set; }
        [Required]
        [StringLength(50)]
        [Display(Name = "First Name")]
        public string contractorFirstName { get; set; }
        [StringLength(50)]
        [Display(Name = "Last Name")]
        public string contractorLastName { get; set; }
        [StringLength(50)]
        [Display(Name = "Routing Number")]
        public string contractorRoutingNum { get; set; }
        [StringLength(50)]
        [Display(Name = "Title Specification")]
        public string contractorTitle { get; set; }
        [StringLength(10)]
        [Display(Name = "Address")]
        public string contractorAddress { get; set; }
        [StringLength(10)]
        [Display(Name = "Email")]
        public string contractorEmail { get; set; }
        [StringLength(10)]
        [Display(Name = "Phone Number")]
        public string contractorPhone { get; set; }

        [InverseProperty(nameof(ContractorJob.contractor))]
        public virtual ICollection<ContractorJob> ContractorJobs { get; set; }
        [InverseProperty(nameof(contractorPayment.contractor))]
        public virtual ICollection<contractorPayment> contractorPayments { get; set; }
    }
}
