﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TexanTurnkey.Models
{
    public partial class ContractorJob
    {
        [Key]
        public short JobID { get; set; }
        [Key]
        public short contractorID { get; set; }

        [ForeignKey(nameof(JobID))]
        [InverseProperty("ContractorJobs")]
        public virtual Job Job { get; set; }
        [ForeignKey(nameof(contractorID))]
        [InverseProperty(nameof(Contractor.ContractorJobs))]
        public virtual Contractor contractor { get; set; }
    }
}
