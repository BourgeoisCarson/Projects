﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace taskTrackerFinal
{
    public partial class TaskViewForm : Form
    {
        public TaskViewForm()
        {
            InitializeComponent();
        }

        private void TaskViewForm_Load(object sender, EventArgs e)
        {   
            //Used to load data
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"Animals.xml");
            dataGridView1.DataSource = dataset.Tables[0];
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
