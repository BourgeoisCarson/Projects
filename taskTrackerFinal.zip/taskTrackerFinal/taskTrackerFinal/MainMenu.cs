﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace taskTrackerFinal
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Connects Main menu to the AddForm
            AddTaskForm newAddForm = new AddTaskForm();
            this.Hide();
            newAddForm.ShowDialog();
            this.Show();
        }

        private void DeleteTasksButton_Click(object sender, EventArgs e)
        {
            //Connects Main menu to the DeleteForm
            DeleteForm newDeleteForm = new DeleteForm();
            this.Hide();
            newDeleteForm.ShowDialog();
            this.Show();
        }

        private void ViewTaskButton_Click(object sender, EventArgs e)
        {
            //Connects Main menu to the ViewForm
            TaskViewForm newViewForm = new TaskViewForm();
            this.Hide();
            newViewForm.ShowDialog();
            this.Show();
        }
    }

}
