﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Xml;

namespace taskTrackerFinal
{
   
    public partial class DeleteForm : Form
    {        
        public DeleteForm()
        {
            InitializeComponent();
        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {
            // Loads XML to DataGrid upon opening
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"Animals.xml");
            dataGridView1.DataSource = dataset.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {   
            //Create and load new XML DOC
            XmlDocument doc = new XmlDocument();
            doc.Load(@"Animals.xml");



            //Selects the "newTask" node and deletes the parent
            //node for "taskName"
            foreach (XmlNode xNode in doc.SelectNodes("Tasks/newTask"))

                if (xNode.SelectSingleNode("taskName").InnerText == textBox1.Text) xNode.ParentNode.RemoveChild(xNode);

            doc.Save(@"Animals.xml");
            MessageBox.Show("Task deleted");


            //Displays XML DOC after deleting task
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"Animals.xml");
            dataGridView1.DataSource = dataset.Tables[0];

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }


    }
}
