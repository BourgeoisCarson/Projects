﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace taskTrackerFinal
{
    [Serializable()]
    public partial class AddTaskForm : Form
    {
        
        public AddTaskForm()
        {
            InitializeComponent();
        }

        private void AddTaskForm_Load(object sender, EventArgs e)
        {
           //Displays XML in GridView when page
           //is loaded
           DataSet dataset = new DataSet();
           dataset.ReadXml(@"Animals.xml");
           dataGridView1.DataSource = dataset.Tables[0];
        }

        public void AddButton_Click(object sender, EventArgs e)
        {
            DateTime newDate = new DateTime();
            newDate = dateTimePicker1.Value;


            //Creating Nodes in XML File
            XmlDocument doc = new XmlDocument();
            doc.Load(@"Animals.xml");
            XmlNode newTask = doc.CreateElement("newTask");
            XmlNode taskDate = doc.CreateElement("taskDate");
            XmlNode taskName = doc.CreateElement("taskName");

            
            //Assinging values to the nodes
            taskDate.InnerText = newDate.ToString("MM dd y");
            taskName.InnerText = textBox2.Text;
            newTask.AppendChild(taskDate);
            newTask.AppendChild(taskName);
            doc.DocumentElement.AppendChild(newTask);

            //Saves changes to XML doc
            doc.Save(@"Animals.xml");
            MessageBox.Show("New task added");

            //Displays XML File in GridView
            //AFTER each task is added
            DataSet dataset = new DataSet();
            dataset.ReadXml(@"Animals.xml");
            dataGridView1.DataSource = dataset.Tables[0];
        }

        public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
